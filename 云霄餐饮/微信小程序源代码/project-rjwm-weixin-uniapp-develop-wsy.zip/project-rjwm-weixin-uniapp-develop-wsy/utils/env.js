
// 测试环境
// export const baseUrl = 'http://reggie-dev.itheima.net'
// export const baseUrl = 'http://172.16.43.24:8080'
// export const baseUrl ='https://reggie-parent-t.itheima.net'
export const baseUrl = 'http://2ae29966.r10.cpolar.top'
// 线上环境
// export const baseUrl = 'https://registakeaway.itheima.net'